/**
 * relatorio.js
 * Gera os dados e o HTML do painel de relatórios:
 * - Cards de métricas gerais
 * - Barras de progresso por status
 * - Barras de progresso por profissional
 * - Tabela de consultas nos próximos 7 dias
 */

/**
 * Renderiza o painel de relatório completo.
 * Chamado ao entrar na aba ou ao clicar em "Atualizar".
 */
function gerarRelatorio() {
  const hoje = new Date();
  const em7  = new Date();
  em7.setDate(hoje.getDate() + 7);

  const hStr  = hoje.toISOString().slice(0, 10);
  const e7Str = em7.toISOString().slice(0, 10);

  const agendadas  = consultas.filter(c => c.status === 'Agendada').length;
  const realizadas = consultas.filter(c => c.status === 'Realizada').length;
  const canceladas = consultas.filter(c => c.status === 'Cancelada').length;

  _renderStats(agendadas, realizadas, canceladas);
  _renderPorStatus(agendadas, realizadas, canceladas);
  _renderPorProfissional();
  _renderProximas(hStr, e7Str);
}

/* ---- privado ---- */

function _renderStats(agendadas, realizadas, canceladas) {
  document.getElementById('stats-grid').innerHTML = `
    <div class="stat-card accent">
      <div class="stat-icon" style="color:var(--accent)"><i class="ti ti-users"></i></div>
      <div class="stat-label">Pacientes</div>
      <div class="stat-value">${pacientes.length}</div>
    </div>
    <div class="stat-card blue">
      <div class="stat-icon" style="color:var(--info)"><i class="ti ti-stethoscope"></i></div>
      <div class="stat-label">Profissionais</div>
      <div class="stat-value">${profissionais.length}</div>
    </div>
    <div class="stat-card">
      <div class="stat-icon" style="color:var(--text-muted)"><i class="ti ti-calendar-event"></i></div>
      <div class="stat-label">Total de consultas</div>
      <div class="stat-value">${consultas.length}</div>
    </div>
    <div class="stat-card warn">
      <div class="stat-icon" style="color:var(--warn)"><i class="ti ti-calendar-check"></i></div>
      <div class="stat-label">Agendadas</div>
      <div class="stat-value">${agendadas}</div>
    </div>
    <div class="stat-card accent">
      <div class="stat-icon" style="color:var(--accent)"><i class="ti ti-circle-check"></i></div>
      <div class="stat-label">Realizadas</div>
      <div class="stat-value">${realizadas}</div>
    </div>
    <div class="stat-card danger">
      <div class="stat-icon" style="color:var(--danger)"><i class="ti ti-ban"></i></div>
      <div class="stat-label">Canceladas</div>
      <div class="stat-value">${canceladas}</div>
    </div>
  `;
}

function _renderPorStatus(agendadas, realizadas, canceladas) {
  const el    = document.getElementById('rel-status');
  const total = consultas.length;

  if (!total) {
    el.innerHTML = '<p style="color:var(--text-hint);font-size:14px">Sem dados ainda.</p>';
    return;
  }

  const items = [
    { label: 'Agendadas',  val: agendadas,  color: 'var(--warn)'       },
    { label: 'Realizadas', val: realizadas, color: 'var(--accent-mid)' },
    { label: 'Canceladas', val: canceladas, color: 'var(--danger)'     },
  ];

  el.innerHTML = items.map(s => {
    const pct = Math.round(s.val / total * 100);
    return `
      <div class="progress-row">
        <div class="progress-label">
          <span>${s.label}</span>
          <span>${s.val} (${pct}%)</span>
        </div>
        <div class="progress-track">
          <div class="progress-fill" style="width:${pct}%; background:${s.color}"></div>
        </div>
      </div>`;
  }).join('');
}

function _renderPorProfissional() {
  const el = document.getElementById('rel-profissional');

  const contagem = {};
  consultas.forEach(c => {
    contagem[c.profNome] = (contagem[c.profNome] || 0) + 1;
  });

  const sorted = Object.entries(contagem).sort((a, b) => b[1] - a[1]);
  const maxVal = sorted[0]?.[1] || 1;

  if (!sorted.length) {
    el.innerHTML = '<p style="color:var(--text-hint);font-size:14px">Sem dados ainda.</p>';
    return;
  }

  el.innerHTML = sorted.map(([nome, qtd]) => {
    const pct = Math.round(qtd / maxVal * 100);
    return `
      <div class="progress-row">
        <div class="progress-label">
          <span>${nome}</span>
          <span>${qtd} consulta${qtd !== 1 ? 's' : ''}</span>
        </div>
        <div class="progress-track">
          <div class="progress-fill" style="width:${pct}%; background:var(--info)"></div>
        </div>
      </div>`;
  }).join('');
}

function _renderProximas(hStr, e7Str) {
  const proximas = consultas
    .filter(c => c.status === 'Agendada' && c.data >= hStr && c.data <= e7Str)
    .sort((a, b) => (a.data + a.hora).localeCompare(b.data + b.hora));

  const tbody = document.getElementById('rel-proximas');
  const empty = document.getElementById('empty-proximas');

  if (!proximas.length) {
    tbody.innerHTML = '';
    empty.classList.remove('hidden');
    return;
  }

  empty.classList.add('hidden');
  tbody.innerHTML = proximas.map(c => `
    <tr>
      <td><strong>${formatDate(c.data)}</strong> ${c.hora}</td>
      <td>${c.pacNome}</td>
      <td>${c.profNome}</td>
      <td>${c.profEsp}</td>
      <td>${c.tipo}</td>
      <td>${statusBadge(c.status)}</td>
    </tr>
  `).join('');
}
