/**
 * profissionais.js
 * Funções de cadastro, edição, exclusão e renderização de profissionais de saúde.
 */

/**
 * Salva ou atualiza um profissional.
 * Valida nome e especialidade antes de persistir.
 */
function salvarProfissional() {
  const nome = document.getElementById('prof-nome').value.trim();
  const esp  = document.getElementById('prof-esp').value;

  if (!nome || !esp) {
    showAlert('alert-prof', 'Preencha o nome e a especialidade.', 'error');
    return;
  }

  const obj = {
    id:      editProfissionalId || uid(),
    nome,
    esp,
    crm:     document.getElementById('prof-crm').value.trim(),
    tel:     document.getElementById('prof-tel').value.trim(),
    email:   document.getElementById('prof-email').value.trim(),
    horario: document.getElementById('prof-horario').value.trim(),
  };

  if (editProfissionalId) {
    const idx = profissionais.findIndex(p => p.id === editProfissionalId);
    profissionais[idx] = obj;
    editProfissionalId = null;
    showAlert('alert-prof', 'Profissional atualizado com sucesso!', 'success');
  } else {
    profissionais.push(obj);
    showAlert('alert-prof', 'Profissional cadastrado com sucesso!', 'success');
  }

  limparFormProfissional();
  renderProfissionais();
}

/**
 * Limpa o formulário de profissional e encerra o modo de edição.
 */
function limparFormProfissional() {
  ['prof-nome', 'prof-crm', 'prof-tel', 'prof-email', 'prof-horario']
    .forEach(id => { document.getElementById(id).value = ''; });
  document.getElementById('prof-esp').value = '';
  editProfissionalId = null;
}

/**
 * Preenche o formulário com os dados de um profissional para edição.
 * @param {string} id - ID do profissional
 */
function editarProfissional(id) {
  const p = profissionais.find(x => x.id === id);
  if (!p) return;
  editProfissionalId = id;
  document.getElementById('prof-nome').value    = p.nome;
  document.getElementById('prof-esp').value     = p.esp;
  document.getElementById('prof-crm').value     = p.crm;
  document.getElementById('prof-tel').value     = p.tel;
  document.getElementById('prof-email').value   = p.email;
  document.getElementById('prof-horario').value = p.horario;
}

/**
 * Remove um profissional após confirmação.
 * @param {string} id - ID do profissional
 */
function excluirProfissional(id) {
  if (!confirm('Deseja excluir este profissional?')) return;
  profissionais = profissionais.filter(p => p.id !== id);
  renderProfissionais();
}

/**
 * Renderiza a tabela de profissionais com filtros por nome e especialidade.
 */
function renderProfissionais() {
  const q   = document.getElementById('filtro-prof').value.toLowerCase();
  const esp = document.getElementById('filtro-esp').value;

  const lista = profissionais.filter(p =>
    p.nome.toLowerCase().includes(q) && (!esp || p.esp === esp)
  );

  document.getElementById('count-profissionais').textContent = profissionais.length;

  const tbody = document.getElementById('tbody-profissionais');
  const empty = document.getElementById('empty-profissionais');

  if (!lista.length) {
    tbody.innerHTML = '';
    empty.classList.remove('hidden');
    return;
  }

  empty.classList.add('hidden');
  tbody.innerHTML = lista.map(p => `
    <tr>
      <td>
        <strong>${p.nome}</strong>
        ${p.horario ? `<br><small style="color:var(--text-hint)">${p.horario}</small>` : ''}
      </td>
      <td><span class="badge badge-blue">${p.esp}</span></td>
      <td>${p.crm || '—'}</td>
      <td>
        <div class="td-actions">
          <button class="btn btn-secondary btn-sm" title="Editar" onclick="editarProfissional('${p.id}')">
            <i class="ti ti-edit"></i>
          </button>
          <button class="btn btn-danger btn-sm" title="Excluir" onclick="excluirProfissional('${p.id}')">
            <i class="ti ti-trash"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}
