/**
 * consultas.js
 * Funções de agendamento, alteração de status, exclusão e renderização de consultas.
 */

/**
 * Atualiza os <select> de paciente e profissional na aba de consultas,
 * preservando a seleção atual quando possível.
 */
function atualizarSelectsConsulta() {
  const sp   = document.getElementById('cons-paciente');
  const sf   = document.getElementById('cons-prof');
  const selP = sp.value;
  const selF = sf.value;

  sp.innerHTML =
    '<option value="">Selecione o paciente...</option>' +
    pacientes.map(p =>
      `<option value="${p.id}" ${selP === p.id ? 'selected' : ''}>${p.nome}</option>`
    ).join('');

  sf.innerHTML =
    '<option value="">Selecione o profissional...</option>' +
    profissionais.map(p =>
      `<option value="${p.id}" ${selF === p.id ? 'selected' : ''}>${p.nome} — ${p.esp}</option>`
    ).join('');
}

/**
 * Cria e salva uma nova consulta com status "Agendada".
 * Valida todos os campos obrigatórios antes de persistir.
 */
function salvarConsulta() {
  const pacId  = document.getElementById('cons-paciente').value;
  const profId = document.getElementById('cons-prof').value;
  const data   = document.getElementById('cons-data').value;
  const hora   = document.getElementById('cons-hora').value;

  if (!pacId || !profId || !data || !hora) {
    showAlert('alert-consulta', 'Preencha todos os campos obrigatórios.', 'error');
    return;
  }

  const pac  = pacientes.find(p => p.id === pacId);
  const prof = profissionais.find(p => p.id === profId);

  const obj = {
    id:       uid(),
    pacId,
    profId,
    pacNome:  pac.nome,
    profNome: prof.nome,
    profEsp:  prof.esp,
    data,
    hora,
    tipo:     document.getElementById('cons-tipo').value,
    obs:      document.getElementById('cons-obs').value.trim(),
    status:   'Agendada',
  };

  consultas.push(obj);
  showAlert('alert-consulta', 'Consulta agendada com sucesso!', 'success');
  limparFormConsulta();
  renderConsultas();
}

/**
 * Limpa o formulário de nova consulta.
 */
function limparFormConsulta() {
  document.getElementById('cons-paciente').value = '';
  document.getElementById('cons-prof').value     = '';
  document.getElementById('cons-data').value     = '';
  document.getElementById('cons-hora').value     = '';
  document.getElementById('cons-obs').value      = '';
}

/**
 * Altera o status de uma consulta existente.
 * @param {string} id     - ID da consulta
 * @param {string} status - Novo status ('Realizada' | 'Cancelada')
 */
function alterarStatusConsulta(id, status) {
  const c = consultas.find(x => x.id === id);
  if (c) {
    c.status = status;
    renderConsultas();
  }
}

/**
 * Remove uma consulta após confirmação.
 * @param {string} id - ID da consulta
 */
function excluirConsulta(id) {
  if (!confirm('Deseja excluir este agendamento?')) return;
  consultas = consultas.filter(c => c.id !== id);
  renderConsultas();
}

/**
 * Renderiza a tabela de consultas com filtros por data e status.
 * Ordena as consultas por data/hora crescente.
 */
function renderConsultas() {
  const dataFiltro   = document.getElementById('filtro-data-cons').value;
  const statusFiltro = document.getElementById('filtro-status-cons').value;

  let lista = [...consultas].sort((a, b) =>
    (a.data + a.hora).localeCompare(b.data + b.hora)
  );

  if (dataFiltro)   lista = lista.filter(c => c.data   === dataFiltro);
  if (statusFiltro) lista = lista.filter(c => c.status === statusFiltro);

  document.getElementById('count-consultas').textContent = consultas.length;

  const tbody = document.getElementById('tbody-consultas');
  const empty = document.getElementById('empty-consultas');

  if (!lista.length) {
    tbody.innerHTML = '';
    empty.classList.remove('hidden');
    return;
  }

  empty.classList.add('hidden');
  tbody.innerHTML = lista.map(c => `
    <tr>
      <td>
        <strong>${formatDate(c.data)}</strong>
        <br><small style="color:var(--text-hint)">${c.hora}</small>
      </td>
      <td>${c.pacNome}</td>
      <td>
        ${c.profNome}
        <br><small style="color:var(--text-hint)">${c.profEsp}</small>
      </td>
      <td>${c.tipo}</td>
      <td>${statusBadge(c.status)}</td>
      <td>
        <div class="td-actions">
          ${c.status === 'Agendada' ? `
            <button class="btn btn-secondary btn-sm" title="Marcar como realizada"
              onclick="alterarStatusConsulta('${c.id}', 'Realizada')">
              <i class="ti ti-check"></i>
            </button>
            <button class="btn btn-danger btn-sm" title="Cancelar consulta"
              onclick="alterarStatusConsulta('${c.id}', 'Cancelada')">
              <i class="ti ti-ban"></i>
            </button>
          ` : ''}
          <button class="btn btn-danger btn-sm" title="Excluir"
            onclick="excluirConsulta('${c.id}')">
            <i class="ti ti-trash"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}
