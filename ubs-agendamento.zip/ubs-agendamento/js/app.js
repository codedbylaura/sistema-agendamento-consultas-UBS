/**
 * app.js
 * Inicialização da aplicação e controle de navegação entre seções.
 * Este é o ponto de entrada principal — carregado por último no HTML.
 */

/**
 * Exibe a seção solicitada e atualiza o estado ativo dos botões de navegação.
 * @param {string} name - Nome da seção ('pacientes' | 'profissionais' | 'consultas' | 'relatorio')
 */
function showSection(name) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('nav button').forEach(b => b.classList.remove('active'));

  document.getElementById('section-' + name).classList.add('active');
  document.getElementById('tab-'     + name).classList.add('active');

  // Ações específicas ao entrar em cada seção
  if (name === 'relatorio') gerarRelatorio();
  if (name === 'consultas') atualizarSelectsConsulta();
}

// Inicializa as listagens vazias ao carregar a página
renderPacientes();
renderProfissionais();
renderConsultas();
