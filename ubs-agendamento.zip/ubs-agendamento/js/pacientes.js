/**
 * pacientes.js
 * Funções de cadastro, edição, exclusão e renderização de pacientes.
 */

/**
 * Salva ou atualiza um paciente.
 * Lê os campos do formulário, valida o nome e persiste no array global.
 */
function salvarPaciente() {
  const nome = document.getElementById('pac-nome').value.trim();
  if (!nome) {
    showAlert('alert-paciente', 'Informe o nome do paciente.', 'error');
    return;
  }

  const obj = {
    id:   editPacienteId || uid(),
    nome,
    cpf:  document.getElementById('pac-cpf').value.trim(),
    nasc: document.getElementById('pac-nasc').value,
    tel:  document.getElementById('pac-tel').value.trim(),
    sus:  document.getElementById('pac-sus').value.trim(),
    end:  document.getElementById('pac-end').value.trim(),
    obs:  document.getElementById('pac-obs').value.trim(),
  };

  if (editPacienteId) {
    const idx = pacientes.findIndex(p => p.id === editPacienteId);
    pacientes[idx] = obj;
    editPacienteId = null;
    showAlert('alert-paciente', 'Paciente atualizado com sucesso!', 'success');
  } else {
    pacientes.push(obj);
    showAlert('alert-paciente', 'Paciente cadastrado com sucesso!', 'success');
  }

  limparFormPaciente();
  renderPacientes();
}

/**
 * Limpa todos os campos do formulário de paciente e encerra o modo de edição.
 */
function limparFormPaciente() {
  ['pac-nome', 'pac-cpf', 'pac-nasc', 'pac-tel', 'pac-sus', 'pac-end', 'pac-obs']
    .forEach(id => { document.getElementById(id).value = ''; });
  editPacienteId = null;
}

/**
 * Preenche o formulário com os dados de um paciente para edição.
 * @param {string} id - ID do paciente
 */
function editarPaciente(id) {
  const p = pacientes.find(x => x.id === id);
  if (!p) return;
  editPacienteId = id;
  document.getElementById('pac-nome').value = p.nome;
  document.getElementById('pac-cpf').value  = p.cpf;
  document.getElementById('pac-nasc').value = p.nasc;
  document.getElementById('pac-tel').value  = p.tel;
  document.getElementById('pac-sus').value  = p.sus;
  document.getElementById('pac-end').value  = p.end;
  document.getElementById('pac-obs').value  = p.obs;
}

/**
 * Remove um paciente do array após confirmação do usuário.
 * @param {string} id - ID do paciente
 */
function excluirPaciente(id) {
  if (!confirm('Deseja excluir este paciente?')) return;
  pacientes = pacientes.filter(p => p.id !== id);
  renderPacientes();
}

/**
 * Renderiza a tabela de pacientes aplicando o filtro de busca.
 * Atualiza o contador e o estado vazio.
 */
function renderPacientes() {
  const q     = document.getElementById('filtro-paciente').value.toLowerCase();
  const lista = pacientes.filter(p =>
    p.nome.toLowerCase().includes(q) || p.cpf.includes(q)
  );

  document.getElementById('count-pacientes').textContent = pacientes.length;

  const tbody = document.getElementById('tbody-pacientes');
  const empty = document.getElementById('empty-pacientes');

  if (!lista.length) {
    tbody.innerHTML = '';
    empty.classList.remove('hidden');
    return;
  }

  empty.classList.add('hidden');
  tbody.innerHTML = lista.map(p => `
    <tr>
      <td>
        <strong>${p.nome}</strong>
        ${p.obs ? `<br><small style="color:var(--text-hint)">${p.obs.slice(0, 40)}${p.obs.length > 40 ? '…' : ''}</small>` : ''}
      </td>
      <td>${p.cpf  || '—'}</td>
      <td>${p.tel  || '—'}</td>
      <td>
        <div class="td-actions">
          <button class="btn btn-secondary btn-sm" title="Editar" onclick="editarPaciente('${p.id}')">
            <i class="ti ti-edit"></i>
          </button>
          <button class="btn btn-danger btn-sm" title="Excluir" onclick="excluirPaciente('${p.id}')">
            <i class="ti ti-trash"></i>
          </button>
        </div>
      </td>
    </tr>
  `).join('');
}
