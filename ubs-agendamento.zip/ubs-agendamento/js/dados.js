/**
 * dados.js
 * Armazenamento central de dados da aplicação.
 * Todos os outros módulos leem e escrevem nestas variáveis.
 */

let pacientes     = [];
let profissionais = [];
let consultas     = [];

// IDs de edição ativos
let editPacienteId     = null;
let editProfissionalId = null;

/**
 * Gera um ID único baseado em timestamp + random.
 * @returns {string}
 */
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

/**
 * Formata uma string de data ISO (YYYY-MM-DD) para DD/MM/AAAA.
 * @param {string} d
 * @returns {string}
 */
function formatDate(d) {
  if (!d) return '—';
  const [y, m, dd] = d.split('-');
  return `${dd}/${m}/${y}`;
}

/**
 * Retorna o HTML de um badge colorido conforme o status da consulta.
 * @param {string} s - Status da consulta
 * @returns {string}
 */
function statusBadge(s) {
  const map = {
    'Agendada':  'badge-warn',
    'Realizada': 'badge-green',
    'Cancelada': 'badge-danger',
  };
  return `<span class="badge ${map[s] || 'badge-gray'}">${s}</span>`;
}

/**
 * Exibe um alerta temporário em um elemento da página.
 * @param {string} id    - ID do elemento de alerta
 * @param {string} msg   - Mensagem a exibir
 * @param {string} type  - 'success' ou 'error'
 */
function showAlert(id, msg, type) {
  const el = document.getElementById(id);
  const icon = type === 'error' ? 'alert-circle' : 'circle-check';
  el.className = `alert alert-${type === 'error' ? 'error' : 'success'} show`;
  el.innerHTML = `<i class="ti ti-${icon}"></i> ${msg}`;
  setTimeout(() => { el.className = 'alert'; }, 3000);
}
