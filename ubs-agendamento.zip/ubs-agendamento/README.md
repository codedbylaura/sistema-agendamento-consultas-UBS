# UBS — Sistema de Agendamento de Consultas

Sistema frontend em HTML, CSS e JavaScript puro para gerenciamento de consultas em uma Unidade Básica de Saúde (UBS).

## Como executar

### Opção 1 — Live Server (recomendado no VSCode)
1. Instale a extensão **Live Server** de Ritwick Dey no VSCode
2. Abra a pasta `ubs-agendamento` no VSCode
3. Clique com o botão direito em `index.html` → **"Open with Live Server"**
4. O navegador abrirá automaticamente em `http://127.0.0.1:5500`

### Opção 2 — Abrir direto no navegador
Abra o arquivo `index.html` diretamente no navegador (arraste ou duplo clique).
> Ícones e fontes externas exigem conexão com a internet.

---

## Estrutura de arquivos

```
ubs-agendamento/
├── index.html          # Estrutura HTML principal (todas as seções)
├── README.md           # Este arquivo
├── css/
│   └── style.css       # Estilos (variáveis, layout, componentes)
└── js/
    ├── dados.js         # Variáveis globais, uid(), formatDate(), showAlert()
    ├── pacientes.js     # CRUD de pacientes
    ├── profissionais.js # CRUD de profissionais de saúde
    ├── consultas.js     # Agendamento e gestão de consultas
    ├── relatorio.js     # Geração do painel de relatórios
    └── app.js           # Inicialização e controle de navegação
```

---

## Funcionalidades

### Pacientes
- Cadastro com nome, CPF, data de nascimento, telefone, cartão SUS, endereço e observações
- Edição e exclusão
- Busca por nome ou CPF

### Profissionais de Saúde
- Cadastro com nome, especialidade, CRM/COREN, telefone, e-mail e horário
- 9 especialidades disponíveis (Clínica Geral, Enfermagem, Pediatria, etc.)
- Filtro por nome e especialidade
- Edição e exclusão

### Consultas
- Agendamento vinculando paciente e profissional
- Campos: data, horário, tipo de atendimento e observações
- Alteração de status: Agendada → Realizada / Cancelada
- Filtros por data e status

### Relatório
- Cards com totais: pacientes, profissionais, consultas por status
- Barras de progresso por status das consultas
- Barras de progresso por quantidade de consultas por profissional
- Tabela das consultas agendadas nos próximos 7 dias

---

## Tecnologias utilizadas

- HTML5 semântico
- CSS3 com variáveis customizadas
- JavaScript ES6+ (sem frameworks)
- [Tabler Icons](https://tabler-icons.io/) — ícones via CDN

> Os dados ficam em memória durante a sessão.
> Para persistência, os arrays em `js/dados.js` podem ser integrados com `localStorage` ou uma API REST.

---

## Desenvolvido para

Unidade Básica de Saúde — Sistema de Apoio à Gestão de Atendimentos
